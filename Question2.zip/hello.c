/* Simple Linux Kernel display in user mode*/
#include <stdio.h>

int main(void)
{
	printf("Hello from Ruoting Wang!\n");
	return 0;
}

