/* Simple Linux Kernel display in user mode in cpp using cout*/
#include <iostream>

int main(void)
{
	std::cout << "Hello from Ruoting Wang!\n";
	return 0;
}

